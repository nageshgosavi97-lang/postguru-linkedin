import { useState, useEffect } from "react";

const TOPICS = ["SIP & Mutual Funds","Term Insurance","Market Crash Mindset","Financial Freedom","Insurance Myths","Retirement Planning","Tax Saving (80C)","Emergency Fund","Child Education Plan","Health Insurance"];
const TONES  = ["Educational","Motivational","Story-based","Conversational","Bold & Direct"];
const HOOKS  = ["Relatable Scenario","Question Hook","Bold Statement","Data/Stat Lead","Personal Story"];

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Sora:wght@300;400;500;600;700&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0c0c13;--surface:rgba(255,255,255,0.035);--border:rgba(255,255,255,0.07);--accent:#ff9500;--text:#e8dfd4;--muted:rgba(232,223,212,0.45);--radius:16px;--font:'Sora',sans-serif}
body{background:var(--bg);font-family:var(--font);color:var(--text);min-height:100vh}
.app{min-height:100vh;background:var(--bg);background-image:radial-gradient(ellipse 70% 50% at 5% 0%,rgba(255,149,0,0.09) 0%,transparent 55%),radial-gradient(ellipse 50% 60% at 95% 100%,rgba(0,80,200,0.07) 0%,transparent 55%);padding:40px 24px}
.header{max-width:900px;margin:0 auto 36px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.logo{display:flex;align-items:center;gap:10px}
.logo-icon{width:36px;height:36px;background:linear-gradient(135deg,#ff9500,#ff5f00);border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 0 18px rgba(255,149,0,0.3)}
.logo-name{font-family:'Playfair Display',serif;font-size:20px;font-weight:900;color:#fff}
.logo-name span{color:#ff9500}
.li-badge{display:flex;align-items:center;gap:8px;padding:8px 14px;border-radius:10px;font-size:12px;font-weight:600;background:rgba(0,119,181,0.12);border:1px solid rgba(0,119,181,0.25);color:#4da6ff;cursor:pointer;transition:all 0.2s;font-family:var(--font)}
.li-badge:hover{background:rgba(0,119,181,0.2)}
.li-badge.connected{background:rgba(0,200,100,0.1);border-color:rgba(0,200,100,0.25);color:#00c864}
.li-dot{width:7px;height:7px;border-radius:50%;background:currentColor}
.container{max-width:900px;margin:0 auto;display:grid;grid-template-columns:400px 1fr;gap:24px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px}
.card-title{font-size:10px;font-weight:700;letter-spacing:2.5px;text-transform:uppercase;color:rgba(255,149,0,0.65);margin-bottom:18px}
label{display:block;font-size:12px;font-weight:600;color:var(--muted);margin:16px 0 8px}
label:first-of-type{margin-top:0}
input,textarea{width:100%;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:10px;padding:11px 14px;color:var(--text);font-family:var(--font);font-size:13px;outline:none;transition:border-color 0.2s;resize:none}
input:focus,textarea:focus{border-color:rgba(255,149,0,0.45)}
textarea{min-height:80px;line-height:1.6}
.pills{display:flex;flex-wrap:wrap;gap:7px}
.pill{padding:6px 13px;border-radius:20px;border:1px solid var(--border);background:var(--surface);color:var(--muted);font-size:11px;font-weight:600;cursor:pointer;transition:all 0.18s;font-family:var(--font)}
.pill:hover{border-color:rgba(255,149,0,0.35);color:#ff9500}
.pill.active{border-color:#ff9500;background:rgba(255,149,0,0.1);color:#ff9500}
.btn{padding:11px 18px;border-radius:10px;font-family:var(--font);font-size:13px;font-weight:600;cursor:pointer;transition:all 0.2s;border:1px solid var(--border);background:var(--surface);color:var(--text)}
.btn:hover:not(:disabled){background:rgba(255,255,255,0.07)}
.btn:disabled{opacity:0.5;cursor:not-allowed}
.btn-primary{background:linear-gradient(135deg,#ff9500,#ff5f00);border:none;color:#fff;box-shadow:0 4px 16px rgba(255,149,0,0.22);width:100%;margin-top:20px}
.btn-primary:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 8px 24px rgba(255,149,0,0.35)}
.btn-row{display:flex;gap:8px;margin-top:14px}
.btn-row .btn{flex:1;font-size:12px;padding:9px}
.btn-li{background:linear-gradient(135deg,#0077b5,#004f87);border:none;color:#fff;box-shadow:0 4px 16px rgba(0,119,181,0.25)}
.btn-li:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,119,181,0.35)}
.btn-success{background:rgba(0,200,100,0.1);border-color:rgba(0,200,100,0.25);color:#00c864}
.out-box{min-height:200px;display:flex;flex-direction:column}
.out-text{font-size:13.5px;line-height:1.9;white-space:pre-wrap;color:var(--text);flex:1}
.placeholder{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:rgba(232,223,212,0.18);text-align:center;padding:30px 0}
.placeholder .ico{font-size:40px;opacity:.3}
.placeholder p{font-size:13px}
.dots{display:flex;gap:5px;justify-content:center;padding:40px}
.dot{width:7px;height:7px;border-radius:50%;background:#ff9500;animation:bop 1.2s ease-in-out infinite}
.dot:nth-child(2){animation-delay:.2s}.dot:nth-child(3){animation-delay:.4s}
@keyframes bop{0%,60%,100%{transform:translateY(0);opacity:.4}30%{transform:translateY(-9px);opacity:1}}
.char-row{display:flex;justify-content:flex-end;margin-top:8px}
.char-count{font-size:11px;color:var(--muted)}
.toast{position:fixed;bottom:24px;right:24px;background:#1a1a2a;border:1px solid rgba(255,149,0,0.3);border-radius:12px;padding:12px 18px;font-size:13px;color:var(--text);z-index:999;box-shadow:0 8px 32px rgba(0,0,0,0.4);animation:up 0.3s ease}
.toast.err{border-color:rgba(255,80,80,0.4)}
@keyframes up{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}
.err-msg{margin-top:10px;font-size:12px;color:#ff6060}
.info-box{margin-top:14px;padding:12px;background:rgba(0,119,181,0.08);border:1px solid rgba(0,119,181,0.2);border-radius:10px;font-size:12px;color:rgba(77,166,255,0.8);line-height:1.6}
@media(max-width:700px){.container{grid-template-columns:1fr}}
`;

async function callAI(prompt) {
  const res = await fetch("/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt }),
  });
  const data = await res.json();
  return data.text || "";
}

export default function PostGuru({ liName, isConnected }) {
  const [topic, setTopic]     = useState("");
  const [custom, setCustom]   = useState("");
  const [tone, setTone]       = useState("Educational");
  const [hook, setHook]       = useState("Relatable Scenario");
  const [ctx, setCtx]         = useState("");
  const [post, setPost]       = useState("");
  const [loading, setLoading] = useState(false);
  const [posting, setPosting] = useState(false);
  const [err, setErr]         = useState("");
  const [toast, setToast]     = useState({ msg: "", type: "ok" });

  const finalTopic = topic === "__c" ? custom : topic;

  const showToast = (msg, type = "ok") => {
    setToast({ msg, type });
    setTimeout(() => setToast({ msg: "", type: "ok" }), 3000);
  };

  const generate = async () => {
    if (!finalTopic.trim()) { setErr("Topic select karo pehle!"); return; }
    setErr(""); setLoading(true); setPost("");
    try {
      const prompt = `You are an expert LinkedIn content creator for Indian financial advisors writing in Hinglish (Hindi in Roman script + English).

Generate a LinkedIn post:
- Topic: ${finalTopic}
- Tone: ${tone}
- Hook type: ${hook}
- Extra context: ${ctx || "None"}
- Audience: Middle-class Indian families, MFDs, IFAs

Rules:
1. Start with a strong ${hook} in first 2 lines
2. Natural Hinglish: "Yaar sochke dekho...", "Ek baar socho...", "Main aaj ek sach batata hoon..."
3. 150–220 words
4. End with CTA or thought-provoking question
5. 4–6 relevant hashtags at end
6. Short paragraphs, LinkedIn style

Output ONLY the post text. No preamble.`;
      const text = await callAI(prompt);
      setPost(text);
    } catch { setErr("Generation fail ho gayi. Retry karo!"); }
    finally { setLoading(false); }
  };

  const postToLinkedIn = async () => {
    if (!post) return;
    if (!isConnected) {
      showToast("Pehle LinkedIn connect karo!", "err");
      return;
    }
    setPosting(true);
    try {
      const res = await fetch("/api/linkedin-post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: post }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("🎉 Post LinkedIn pe publish ho gaya!");
      } else {
        showToast("Post fail ho gayi: " + (data.error || "Unknown error"), "err");
      }
    } catch { showToast("Network error. Try again!", "err"); }
    finally { setPosting(false); }
  };

  return (
    <>
      <style>{CSS}</style>
      <div className="app">
        <div className="header">
          <div className="logo">
            <div className="logo-icon">✍️</div>
            <div className="logo-name">Post<span>Guru</span></div>
          </div>
          {isConnected ? (
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div className="li-badge connected">
                <div className="li-dot" />
                {liName ? decodeURIComponent(liName) : "LinkedIn Connected"}
              </div>
              <a href="/api/auth/logout" className="btn" style={{ fontSize: 12, padding: "7px 14px", textDecoration: "none" }}>Disconnect</a>
            </div>
          ) : (
            <a href="/api/auth/start" className="li-badge" style={{ textDecoration: "none" }}>
              <div className="li-dot" />
              Connect LinkedIn
            </a>
          )}
        </div>

        <div className="container">
          {/* LEFT: Controls */}
          <div className="card">
            <div className="card-title">Configure Your Post</div>

            <label>Topic chuno</label>
            <div className="pills">
              {TOPICS.map(t => (
                <button key={t} className={`pill ${topic === t ? "active" : ""}`} onClick={() => { setTopic(t); setCustom(""); }}>{t}</button>
              ))}
              <button className={`pill ${topic === "__c" ? "active" : ""}`} onClick={() => setTopic("__c")}>+ Custom</button>
            </div>

            {topic === "__c" && (
              <><label>Apna topic</label>
              <input placeholder="e.g. ULIP vs Term Insurance..." value={custom} onChange={e => setCustom(e.target.value)} /></>
            )}

            <label>Tone</label>
            <div className="pills">{TONES.map(t => <button key={t} className={`pill ${tone === t ? "active" : ""}`} onClick={() => setTone(t)}>{t}</button>)}</div>

            <label>Hook Type</label>
            <div className="pills">{HOOKS.map(h => <button key={h} className={`pill ${hook === h ? "active" : ""}`} onClick={() => setHook(h)}>{h}</button>)}</div>

            <label>Extra Context (optional)</label>
            <textarea placeholder="e.g. SIP ₹5000/month = ₹1Cr in 25 years..." value={ctx} onChange={e => setCtx(e.target.value)} />

            {err && <div className="err-msg">{err}</div>}

            <button className="btn btn-primary" onClick={generate} disabled={loading}>
              {loading ? "Generating..." : "✨ Generate Post"}
            </button>
          </div>

          {/* RIGHT: Output */}
          <div className="card">
            <div className="card-title">Your LinkedIn Post</div>
            <div className="out-box">
              {loading
                ? <div className="dots"><div className="dot" /><div className="dot" /><div className="dot" /></div>
                : post
                  ? <>
                      <div className="out-text">{post}</div>
                      <div className="char-row"><span className="char-count">{post.length} chars</span></div>
                      <div className="btn-row">
                        <button className="btn btn-success" onClick={() => { navigator.clipboard.writeText(post); showToast("Post copy ho gaya!"); }}>📋 Copy</button>
                        <button className="btn" onClick={generate}>🔄 Redo</button>
                      </div>
                      <button
                        className="btn btn-li"
                        style={{ width: "100%", marginTop: 10 }}
                        onClick={postToLinkedIn}
                        disabled={posting || !isConnected}
                      >
                        {posting ? "Posting..." : "🔗 Post to LinkedIn"}
                      </button>
                      {!isConnected && (
                        <div className="info-box">
                          💡 LinkedIn connect karo upar se — phir directly publish kar sakte ho!
                        </div>
                      )}
                    </>
                  : <div className="placeholder">
                      <div className="ico">✍️</div>
                      <p>Topic select karke Generate dabao!</p>
                    </div>
              }
            </div>
          </div>
        </div>

        {toast.msg && (
          <div className={`toast ${toast.type === "err" ? "err" : ""}`}>
            {toast.type === "ok" ? "✅" : "❌"} {toast.msg}
          </div>
        )}
      </div>
    </>
  );
}

export async function getServerSideProps({ req }) {
  const cookies = req.headers.cookie || "";
  const isConnected = cookies.includes("li_token=");
  const liNameMatch = cookies.match(/li_name=([^;]+)/);
  const liName = liNameMatch ? liNameMatch[1] : null;
  return { props: { isConnected, liName } };
}
