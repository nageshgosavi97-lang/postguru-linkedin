export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const token = req.cookies.li_token;
  const sub   = req.cookies.li_sub;

  if (!token || !sub) {
    return res.status(401).json({ error: "Not authenticated. Please connect LinkedIn first." });
  }

  const { text } = req.body;

  if (!text || text.trim().length === 0) {
    return res.status(400).json({ error: "Post text is empty." });
  }

  try {
    const postRes = await fetch("https://api.linkedin.com/rest/posts", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "LinkedIn-Version": "202401",
        "X-Restli-Protocol-Version": "2.0.0",
      },
      body: JSON.stringify({
        author: `urn:li:person:${sub}`,
        commentary: text,
        visibility: "PUBLIC",
        distribution: {
          feedDistribution: "MAIN_FEED",
          targetEntities: [],
          thirdPartyDistributionChannels: [],
        },
        lifecycleState: "PUBLISHED",
        isReshareDisableForOperator: false,
      }),
    });

    if (postRes.status === 201 || postRes.ok) {
      return res.status(200).json({ success: true, message: "Post published on LinkedIn!" });
    }

    const errData = await postRes.json().catch(() => ({}));
    return res.status(400).json({ error: "LinkedIn post failed", details: errData });
  } catch (err) {
    console.error("Post error:", err);
    return res.status(500).json({ error: "Server error" });
  }
}
