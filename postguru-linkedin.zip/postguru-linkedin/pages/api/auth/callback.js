export default async function handler(req, res) {
  const { code, error } = req.query;

  if (error) {
    return res.redirect("/?error=access_denied");
  }

  try {
    // Exchange code for access token
    const tokenRes = await fetch(
      "https://www.linkedin.com/oauth/v2/accessToken",
      {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          code,
          redirect_uri: process.env.NEXT_PUBLIC_URL + "/api/auth/callback",
          client_id: process.env.LINKEDIN_CLIENT_ID,
          client_secret: process.env.LINKEDIN_CLIENT_SECRET,
        }),
      }
    );

    const tokenData = await tokenRes.json();

    if (!tokenData.access_token) {
      return res.redirect("/?error=token_failed");
    }

    // Get LinkedIn user info (person URN)
    const userRes = await fetch("https://api.linkedin.com/v2/userinfo", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const user = await userRes.json();

    // Store token + sub in cookies (1 hour)
    res.setHeader("Set-Cookie", [
      `li_token=${tokenData.access_token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=3600`,
      `li_sub=${user.sub}; Path=/; SameSite=Lax; Max-Age=3600`,
      `li_name=${encodeURIComponent(user.name || "User")}; Path=/; SameSite=Lax; Max-Age=3600`,
    ]);

    res.redirect("/?connected=true");
  } catch (err) {
    console.error("LinkedIn callback error:", err);
    res.redirect("/?error=server_error");
  }
}
