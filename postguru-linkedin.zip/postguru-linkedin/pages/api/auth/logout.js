export default function handler(req, res) {
  res.setHeader("Set-Cookie", [
    "li_token=; Path=/; HttpOnly; Max-Age=0",
    "li_sub=; Path=/; Max-Age=0",
    "li_name=; Path=/; Max-Age=0",
  ]);
  res.redirect("/");
}
