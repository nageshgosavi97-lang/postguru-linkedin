export default function handler(req, res) {
  const params = new URLSearchParams({
    response_type: "code",
    client_id: process.env.LINKEDIN_CLIENT_ID,
    redirect_uri: process.env.NEXT_PUBLIC_URL + "/api/auth/callback",
    scope: "openid profile w_member_social",
    state: "postguru_state_123",
  });
  res.redirect(
    `https://www.linkedin.com/oauth/v2/authorization?${params.toString()}`
  );
}
