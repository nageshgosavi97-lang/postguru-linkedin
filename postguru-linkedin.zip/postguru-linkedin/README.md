# PostGuru — LinkedIn Setup Guide

## Step 1: GitHub pe upload karo

1. GitHub.com pe jao → "New Repository" → Name: `postguru-linkedin` → Create
2. Saari files is repo mein upload karo (ya git use karo)

## Step 2: Vercel pe deploy karo

1. vercel.com pe jao → "Add New Project"
2. GitHub repo select karo: `postguru-linkedin`
3. "Deploy" dabao — first deploy hoga (kaam nahi karega abhi)
4. Tumhe URL milega: `https://postguru-linkedin.vercel.app` (ya kuch aisa)

## Step 3: LinkedIn App mein Callback URL add karo

1. developer.linkedin.com → tumhara app → Auth tab
2. "Authorized redirect URLs" mein add karo:
   `https://your-vercel-url.vercel.app/api/auth/callback`

## Step 4: Vercel mein Environment Variables set karo

Vercel Dashboard → Project → Settings → Environment Variables:

| Key | Value |
|-----|-------|
| `LINKEDIN_CLIENT_ID` | LinkedIn se copy karo |
| `LINKEDIN_CLIENT_SECRET` | LinkedIn se copy karo |
| `NEXT_PUBLIC_URL` | `https://your-vercel-url.vercel.app` |
| `ANTHROPIC_API_KEY` | Anthropic Console se |

## Step 5: Redeploy karo

Vercel → Deployments → "Redeploy" dabao

## Done! 🎉

App open karo → "Connect LinkedIn" click karo → Post generate karo → "Post to LinkedIn" dabao!
